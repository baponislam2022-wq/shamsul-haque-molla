# Al-Haj Md. Shamsul Haque Molla — Biography & Memorial Gallery

A responsive, static biography website built from the biographical text and six images supplied in the conversation.

## Preview locally
1. Extract this ZIP file.
2. Open `index.html` in Chrome, Edge, Firefox, or another modern browser.
3. Keep the `assets` folder beside `index.html`; do not move the images out of it.

## Publish free
The package is a ready static website and can be published using a free static host such as GitHub Pages or Netlify. Upload the contents of this folder (the `index.html` file and `assets` folder) to the hosting provider and follow its publish steps. A custom domain is optional.

## About Blogger
This is a complete static website package, not a Blogger XML theme. Blogger has a different theme format. If you want to use Blogger specifically, create a Blogger blog first and add the biography as pages/posts; upload the six images to Blogger and replace the local `assets/gallery-*.jpg` references with the image URLs Blogger gives you.

## Accuracy note
The biography uses details as supplied by the family/user. Some dates and wording in the source text may require verification against original documents before official use.
